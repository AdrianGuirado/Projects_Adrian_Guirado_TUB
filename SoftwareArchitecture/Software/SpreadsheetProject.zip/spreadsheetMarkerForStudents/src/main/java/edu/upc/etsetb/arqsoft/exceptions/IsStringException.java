package edu.upc.etsetb.arqsoft.exceptions;

/**
 *
 * @author Juan Parada
 */
public class IsStringException extends Exception {
    
}
