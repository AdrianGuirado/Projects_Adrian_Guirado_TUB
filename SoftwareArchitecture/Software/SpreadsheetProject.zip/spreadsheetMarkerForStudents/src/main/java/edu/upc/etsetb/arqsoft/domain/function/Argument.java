package edu.upc.etsetb.arqsoft.domain.function;

import java.util.List;

public interface Argument {
    public List<Number> getValue();
}
