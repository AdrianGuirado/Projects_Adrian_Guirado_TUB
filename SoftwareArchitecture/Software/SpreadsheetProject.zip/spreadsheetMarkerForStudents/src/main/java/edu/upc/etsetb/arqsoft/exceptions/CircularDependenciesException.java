package edu.upc.etsetb.arqsoft.exceptions;

/**
 *
 * @author Juan Parada
 */
public class CircularDependenciesException extends Exception {
    
}
