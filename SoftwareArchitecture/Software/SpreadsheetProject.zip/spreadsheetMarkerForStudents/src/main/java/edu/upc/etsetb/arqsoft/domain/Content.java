package edu.upc.etsetb.arqsoft.domain;

public interface Content {
    public String getContentValue();
}
