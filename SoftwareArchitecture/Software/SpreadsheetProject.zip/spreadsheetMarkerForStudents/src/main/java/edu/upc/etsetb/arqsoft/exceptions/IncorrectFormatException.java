package edu.upc.etsetb.arqsoft.exceptions;

public class IncorrectFormatException extends Exception{

}
