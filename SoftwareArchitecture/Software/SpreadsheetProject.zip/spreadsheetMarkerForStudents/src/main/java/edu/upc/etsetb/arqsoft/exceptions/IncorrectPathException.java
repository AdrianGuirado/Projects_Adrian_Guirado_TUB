package edu.upc.etsetb.arqsoft.exceptions;

public class IncorrectPathException extends Exception{

}
