package edu.upc.etsetb.arqsoft.exceptions;

/**
 *
 * @author Juan Parada
 */
public class IsNumberException extends Exception {
    
}
